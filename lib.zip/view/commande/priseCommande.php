<div class="container h-100 d-flex flex-column justify-content-around">
	<div class="row m-1">
		<div class="col-6 offset-3 ">
			<!--            <h1 class="text-white font-pacifico text-center">Restaurant</h1>-->
<!--			<h3 class="text-white font-pacifico text-center">A la bonne heure</h3>-->
			<div class="text-center"><img height="150" width="auto" src="../../resources/logo/logo.png" alt="Logo Restaurant"></div>
		</div>
	</div>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Card title</h5>
            <p class="card-text">
                Some quick example text to build on the card title and make up the bulk of the
                card's content.
            </p>
            <button type="button" class="btn btn-primary">Button</button>
        </div>
    </div>
	<div class="row m-2 fixed-bottom">


        <div class="row">
            <div class="text-center row m-1 col">
                <a href="#" class="btn btn-info">
                    Annuler
                </a>
            </div>
            <div class="text-center row m-1 col">
                <a href="http://www.google.fr" class="btn btn-info">
                    Suivent
                </a>
            </div>
        </div>
	</div>
</div>
