<section> <?php var_dump($tab_t) ?> </section>
