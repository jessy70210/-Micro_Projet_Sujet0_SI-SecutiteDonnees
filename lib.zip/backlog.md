# Backlog de POC

## Les pages

- Présentation du reto avec btn "consulter le menu pour commandé"
- Affichage du menu avec choix de la composition (nb menu = nb personne)
- Recupitulatif avec poisibilité de modification
- Validation de la commande + payment
- Fin 

## backend

- jeu de données avec les modèles 